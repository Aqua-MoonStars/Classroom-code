﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Security.Cryptography.X509Certificates;
public class Classname
{
 List<Student>
    Students = new List<Student>();
    Student student = new Student();
 s
}

