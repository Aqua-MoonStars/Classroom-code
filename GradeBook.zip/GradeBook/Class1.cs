﻿namespace Gradebook;

public class Class1
{

}
